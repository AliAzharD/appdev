namespace THA_W4_Ali_Azhar_D
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button_submit_Click(object sender, EventArgs e)
        {
            
            if (Convert.ToInt32(textBox_age.Text) < 18)
            {
                MessageBox.Show("Name: " + textBox_nama.Text + "\nEmail: " + textBox_email.Text + "\nPhone Number: " + textBox_nomertelp.Text + "\nYou are minor");
            }
            else
            {
                MessageBox.Show("Name: " + textBox_nama.Text + "\nEmail: " + textBox_email.Text + "\nPhone Number: " + textBox_nomertelp.Text + "\nYou are adult");
            }
        }

        private void button_clear_Click(object sender, EventArgs e)
        {
            textBox_nama.Clear();   
            textBox_age.Clear();
            textBox_email.Clear();
            textBox_nomertelp.Clear();
        }
    }
}