﻿namespace THA_W4_Ali_Azhar_D
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1_nama = new System.Windows.Forms.Label();
            this.textBox_nama = new System.Windows.Forms.TextBox();
            this.textBox_age = new System.Windows.Forms.TextBox();
            this.textBox_email = new System.Windows.Forms.TextBox();
            this.textBox_nomertelp = new System.Windows.Forms.TextBox();
            this.label2_age = new System.Windows.Forms.Label();
            this.label3_email = new System.Windows.Forms.Label();
            this.label4_nomertelp = new System.Windows.Forms.Label();
            this.button_submit = new System.Windows.Forms.Button();
            this.button_clear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1_nama
            // 
            this.label1_nama.AutoSize = true;
            this.label1_nama.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1_nama.Location = new System.Drawing.Point(170, 83);
            this.label1_nama.Name = "label1_nama";
            this.label1_nama.Size = new System.Drawing.Size(44, 17);
            this.label1_nama.TabIndex = 0;
            this.label1_nama.Text = "Nama";
            // 
            // textBox_nama
            // 
            this.textBox_nama.Location = new System.Drawing.Point(233, 83);
            this.textBox_nama.Name = "textBox_nama";
            this.textBox_nama.Size = new System.Drawing.Size(125, 27);
            this.textBox_nama.TabIndex = 1;
            // 
            // textBox_age
            // 
            this.textBox_age.Location = new System.Drawing.Point(234, 140);
            this.textBox_age.Name = "textBox_age";
            this.textBox_age.Size = new System.Drawing.Size(125, 27);
            this.textBox_age.TabIndex = 2;
            // 
            // textBox_email
            // 
            this.textBox_email.Location = new System.Drawing.Point(234, 201);
            this.textBox_email.Name = "textBox_email";
            this.textBox_email.Size = new System.Drawing.Size(125, 27);
            this.textBox_email.TabIndex = 3;
            // 
            // textBox_nomertelp
            // 
            this.textBox_nomertelp.Location = new System.Drawing.Point(234, 261);
            this.textBox_nomertelp.Name = "textBox_nomertelp";
            this.textBox_nomertelp.Size = new System.Drawing.Size(125, 27);
            this.textBox_nomertelp.TabIndex = 4;
            // 
            // label2_age
            // 
            this.label2_age.AutoSize = true;
            this.label2_age.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2_age.Location = new System.Drawing.Point(181, 146);
            this.label2_age.Name = "label2_age";
            this.label2_age.Size = new System.Drawing.Size(33, 17);
            this.label2_age.TabIndex = 5;
            this.label2_age.Text = "Age";
            // 
            // label3_email
            // 
            this.label3_email.AutoSize = true;
            this.label3_email.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3_email.Location = new System.Drawing.Point(173, 207);
            this.label3_email.Name = "label3_email";
            this.label3_email.Size = new System.Drawing.Size(41, 17);
            this.label3_email.TabIndex = 6;
            this.label3_email.Text = "Email";
            // 
            // label4_nomertelp
            // 
            this.label4_nomertelp.AutoSize = true;
            this.label4_nomertelp.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4_nomertelp.Location = new System.Drawing.Point(131, 267);
            this.label4_nomertelp.Name = "label4_nomertelp";
            this.label4_nomertelp.Size = new System.Drawing.Size(97, 17);
            this.label4_nomertelp.TabIndex = 7;
            this.label4_nomertelp.Text = "Phone Number";
            this.label4_nomertelp.Click += new System.EventHandler(this.label4_Click);
            // 
            // button_submit
            // 
            this.button_submit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button_submit.ForeColor = System.Drawing.Color.Black;
            this.button_submit.Location = new System.Drawing.Point(635, 397);
            this.button_submit.Name = "button_submit";
            this.button_submit.Size = new System.Drawing.Size(94, 29);
            this.button_submit.TabIndex = 10;
            this.button_submit.Text = "Submit";
            this.button_submit.UseVisualStyleBackColor = false;
            this.button_submit.Click += new System.EventHandler(this.button_submit_Click);
            // 
            // button_clear
            // 
            this.button_clear.BackColor = System.Drawing.Color.Red;
            this.button_clear.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_clear.Location = new System.Drawing.Point(30, 406);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(94, 29);
            this.button_clear.TabIndex = 11;
            this.button_clear.Text = "Clear";
            this.button_clear.UseVisualStyleBackColor = false;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_clear);
            this.Controls.Add(this.button_submit);
            this.Controls.Add(this.label4_nomertelp);
            this.Controls.Add(this.label3_email);
            this.Controls.Add(this.label2_age);
            this.Controls.Add(this.textBox_nomertelp);
            this.Controls.Add(this.textBox_email);
            this.Controls.Add(this.textBox_age);
            this.Controls.Add(this.textBox_nama);
            this.Controls.Add(this.label1_nama);
            this.Name = "Form1";
            this.Text = "Take Home Assignment Week 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1_nama;
        private TextBox textBox_nama;
        private TextBox textBox_age;
        private TextBox textBox_email;
        private TextBox textBox_nomertelp;
        private Label label2_age;
        private Label label3_email;
        private Label label4_nomertelp;
        private Button button_submit;
        private Button button_clear;
    }
}